using System;

namespace UserApi.DTOs
{
    public class UserResponseDto
    {
        public int UserId { get; set; }
        public string FirstName { get; set; } = null!;
        public string LastName { get; set; } = null!;
        public string Email { get; set; } = null!;
        public string MobileNumber { get; set; } = null!;
        public string Designation { get; set; } = null!;
        public string? Gender { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string? HigherQualification { get; set; }
        public string? AddressLine1 { get; set; }
        public string? AddressLine2 { get; set; }
        public string? City { get; set; }
        public string? State { get; set; }
        public string? Pincode { get; set; }
        public string? ProfileImageBase64 { get; set; }
    }
}
