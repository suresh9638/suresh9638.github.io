using System;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;

namespace UserApi.DTOs
{
    public class UserCreateDto
    {
        [Required]
        [StringLength(100)]
        public string FirstName { get; set; } = null!;

        [Required]
        [StringLength(100)]
        public string LastName { get; set; } = null!;

        [Required]
        [RegularExpression(@"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$", ErrorMessage = "Invalid Email Format")]
        [StringLength(100)]
        public string Email { get; set; } = null!;

        [Required]
        [RegularExpression(@"^\+?[0-9]{10,15}$", ErrorMessage = "Invalid Mobile Number")]
        [StringLength(20)]
        public string MobileNumber { get; set; } = null!;

        [Required]
        [StringLength(100)]
        public string Designation { get; set; } = null!;

        [StringLength(10)]
        public string? Gender { get; set; }

        [Required]
        public DateTime DateOfBirth { get; set; }

        [StringLength(50)]
        public string? HigherQualification { get; set; }

        [StringLength(255)]
        public string? AddressLine1 { get; set; }

        [StringLength(255)]
        public string? AddressLine2 { get; set; }

        [StringLength(100)]
        public string? City { get; set; }

        [StringLength(100)]
        public string? State { get; set; }

        [StringLength(20)]
        public string? Pincode { get; set; }

        [Required(ErrorMessage = "Profile Image is required for creation.")]
        public IFormFile ProfileImageFile { get; set; } = null!;
    }
}
