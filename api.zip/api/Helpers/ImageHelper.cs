using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace UserApi.Helpers
{
    public static class ImageHelper
    {
        public static async Task<byte[]> ConvertToBytesAsync(IFormFile file)
        {
            if (file == null || file.Length == 0) return Array.Empty<byte>();

            if (!file.ContentType.StartsWith("image/"))
            {
                throw new Exception("Only image files are allowed.");
            }

            if (file.Length > 10 * 1024 * 1024)
            {
                throw new Exception("File size must strictly be less than 10MB");
            }

            var extension = Path.GetExtension(file.FileName).ToLower();
            if (extension != ".jpg" && extension != ".jpeg" && extension != ".png" && extension != ".gif" && extension != ".webp")
            {
                throw new Exception("Invalid image extension. Only jpg, jpeg, png, gif, and webp are allowed.");
            }

            using var memoryStream = new MemoryStream();
            await file.CopyToAsync(memoryStream);
            return memoryStream.ToArray();
        }

        public static string? ConvertToBase64(byte[]? imageBytes)
        {
            if (imageBytes == null || imageBytes.Length == 0) return null;
            string base64String = Convert.ToBase64String(imageBytes);
            return $"data:image/jpeg;base64,{base64String}";
        }
    }
}
