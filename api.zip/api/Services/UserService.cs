using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UserApi.DTOs;
using UserApi.Helpers;
using UserApi.Models;
using UserApi.Repository;

namespace UserApi.Services
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;

        public UserService(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        public async Task<IEnumerable<UserResponseDto>> GetAllUsersAsync()
        {
            var users = await _userRepository.GetAllAsync();
            return users.Select(MapToResponseDto);
        }

        public async Task<UserResponseDto?> GetUserByIdAsync(int id)
        {
            var user = await _userRepository.GetByIdAsync(id);
            if (user == null) return null;
            return MapToResponseDto(user);
        }

        public async Task<UserResponseDto> AddUserAsync(UserCreateDto userDto)
        {
            ValidateAge(userDto.DateOfBirth);

            var user = new User
            {
                FirstName = userDto.FirstName,
                LastName = userDto.LastName,
                Email = userDto.Email,
                MobileNumber = userDto.MobileNumber,
                Designation = userDto.Designation,
                Gender = userDto.Gender,
                DateOfBirth = userDto.DateOfBirth,
                HigherQualification = userDto.HigherQualification,
                AddressLine1 = userDto.AddressLine1,
                AddressLine2 = userDto.AddressLine2,
                City = userDto.City,
                State = userDto.State,
                Pincode = userDto.Pincode
            };

            if (userDto.ProfileImageFile != null)
            {
                user.ProfileImage = await ImageHelper.ConvertToBytesAsync(userDto.ProfileImageFile);
            }

            var createdUser = await _userRepository.AddAsync(user);
            return MapToResponseDto(createdUser);
        }

        public async Task<UserResponseDto> UpdateUserAsync(int id, UserUpdateDto userDto)
        {
            var existingUser = await _userRepository.GetByIdAsync(id);
            if (existingUser == null)
            {
                throw new KeyNotFoundException($"User with Id {id} not found.");
            }

            ValidateAge(userDto.DateOfBirth);

            existingUser.FirstName = userDto.FirstName;
            existingUser.LastName = userDto.LastName;
            existingUser.Email = userDto.Email;
            existingUser.MobileNumber = userDto.MobileNumber;
            existingUser.Designation = userDto.Designation;
            existingUser.Gender = userDto.Gender;
            existingUser.DateOfBirth = userDto.DateOfBirth;
            existingUser.HigherQualification = userDto.HigherQualification;
            existingUser.AddressLine1 = userDto.AddressLine1;
            existingUser.AddressLine2 = userDto.AddressLine2;
            existingUser.City = userDto.City;
            existingUser.State = userDto.State;
            existingUser.Pincode = userDto.Pincode;

            if (userDto.ProfileImageFile != null)
            {
                existingUser.ProfileImage = await ImageHelper.ConvertToBytesAsync(userDto.ProfileImageFile);
            }

            await _userRepository.UpdateAsync(existingUser);
            return MapToResponseDto(existingUser);
        }

        public async Task DeleteUserAsync(int id)
        {
            await _userRepository.DeleteAsync(id);
        }

        private void ValidateAge(DateTime dateOfBirth)
        {
            var age = DateTime.Today.Year - dateOfBirth.Year;
            if (dateOfBirth.Date > DateTime.Today.AddYears(-age)) age--;

            if (age < 18 || age > 100)
            {
                throw new Exception("Age must be between 18 and 100 years.");
            }
        }

        private UserResponseDto MapToResponseDto(User user)
        {
            return new UserResponseDto
            {
                UserId = user.UserId,
                FirstName = user.FirstName,
                LastName = user.LastName,
                Email = user.Email,
                MobileNumber = user.MobileNumber,
                Designation = user.Designation,
                Gender = user.Gender,
                DateOfBirth = user.DateOfBirth,
                HigherQualification = user.HigherQualification,
                AddressLine1 = user.AddressLine1,
                AddressLine2 = user.AddressLine2,
                City = user.City,
                State = user.State,
                Pincode = user.Pincode,
                ProfileImageBase64 = ImageHelper.ConvertToBase64(user.ProfileImage)
            };
        }
    }
}
