using System.Collections.Generic;
using System.Threading.Tasks;
using UserApi.DTOs;

namespace UserApi.Services
{
    public interface IUserService
    {
        Task<IEnumerable<UserResponseDto>> GetAllUsersAsync();
        Task<UserResponseDto?> GetUserByIdAsync(int id);
        Task<UserResponseDto> AddUserAsync(UserCreateDto userDto);
        Task<UserResponseDto> UpdateUserAsync(int id, UserUpdateDto userDto);
        Task DeleteUserAsync(int id);
    }
}
