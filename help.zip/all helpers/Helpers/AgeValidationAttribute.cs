﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;

public class AgeValidationAttribute : ValidationAttribute, IClientModelValidator
{
    private readonly int _minAge;
    private readonly int _maxAge;

    public AgeValidationAttribute(int minAge, int maxAge)
    {
        _minAge = minAge;
        _maxAge = maxAge;
    }

    protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
    {
        if (value == null)
            return new ValidationResult("Date of Birth is required");

        DateTime dob = (DateTime)value;
        var today = DateTime.Today;

        int age = today.Year - dob.Year;
        if (dob > today.AddYears(-age)) age--;

        if (age < _minAge || age > _maxAge)
        {
            return new ValidationResult($"Age must be between {_minAge} and {_maxAge}");
        }

        return ValidationResult.Success;
    }

    // 👉 This adds data-* attributes in HTML
    public void AddValidation(ClientModelValidationContext context)
    {
        context.Attributes.Add("data-val", "true");
        context.Attributes.Add("data-val-age", $"Age must be between {_minAge} and {_maxAge}");
        context.Attributes.Add("data-val-age-min", _minAge.ToString());
        context.Attributes.Add("data-val-age-max", _maxAge.ToString());
    }
}