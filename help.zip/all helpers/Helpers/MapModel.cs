﻿using test.Models;
using test.ViewModels;

namespace test.Helpers
{
    public static class MapModel
    {
        public static async Task<User> MapToModel(UserViewModel vm)
        {
            if (vm == null) return null;

            return new User
            {
                UserId = vm.UserId,
                FirstName = vm.FirstName,
                LastName = vm.LastName,
                Email = vm.Email,
                MobileNumber = vm.MobileNumber,
                Designation = vm.Designation,
                Gender = vm.Gender,
                DateOfBirth = vm.DateOfBirth,
                HigherQualification = vm.HigherQualification,
                AddressLine1 = vm.AddressLine1,
                AddressLine2 = vm.AddressLine2,
                City = vm.City,
                State = vm.State,
                Pincode = vm.Pincode,

                // Convert Base64 to byte[]
                ProfileImage = vm.ProfileImageFile!=null
                    ? await ImageHelper.ConvertToBytesAsync (vm.ProfileImageFile)
                    : null
            };
        }
        public static async Task<UserViewModel> MapToViewModel(User model)
        {
            if (model == null) return null;

            return new UserViewModel
            {
                UserId = model.UserId,
                FirstName = model.FirstName,
                LastName = model.LastName,
                Email = model.Email,
                MobileNumber = model.MobileNumber,
                Designation = model.Designation,
                Gender = model.Gender,
                DateOfBirth = model.DateOfBirth,
                HigherQualification = model.HigherQualification,
                AddressLine1 = model.AddressLine1,
                AddressLine2 = model.AddressLine2,
                City = model.City,
                State = model.State,
                Pincode = model.Pincode,

                // Convert byte[] to Base64
                ProfileImageBase64 = model.ProfileImage != null
                    ? ImageHelper.ConvertToBase64(model.ProfileImage)
                    : null
            };
        }
    }
}
