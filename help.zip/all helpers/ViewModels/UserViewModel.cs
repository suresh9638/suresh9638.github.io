using System;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using Microsoft.AspNetCore.Http;
using test.Models;

namespace test.ViewModels
{
    public class AllowedExtensionsAttribute : ValidationAttribute
    {
        private readonly string[] _extensions;
        public AllowedExtensionsAttribute(string[] extensions)
        {
            _extensions = extensions;
        }

        protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
        {
            var file = value as IFormFile;
            if (file != null)
            {
                var extension = Path.GetExtension(file.FileName);
                if (extension == null || !_extensions.Contains(extension.ToLower()))
                {
                    return new ValidationResult(GetErrorMessage());
                }
            }
            return ValidationResult.Success;
        }

        public string GetErrorMessage()
        {
            return $"This file extension is not allowed! Allowed image extensions are: {string.Join(", ", _extensions)}.";
        }
    }

    public class UserViewModel
    {
        public int UserId { get; set; }

        [Required(ErrorMessage = "First Name is required.")]
        [StringLength(100)]
        [Display(Name = "First Name")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Last Name is required.")]
        [StringLength(100)]
        [Display(Name = "Last Name")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Email is required.")]
        [RegularExpression(@"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$", ErrorMessage = "Invalid Email Address Format")]
        [StringLength(100)]
        public string Email { get; set; }

        [Required(ErrorMessage = "Mobile Number is required.")]
        [RegularExpression(@"^\+?[0-9]{10,15}$", ErrorMessage = "Mobile number must be 10-15 digits, optionally starting with +")]
        [Display(Name = "Mobile Number")]
        public string MobileNumber { get; set; }

        [Required(ErrorMessage = "Designation is required.")]
        [StringLength(100)]
        public string Designation { get; set; }

        [Required(ErrorMessage = "Gender is required.")]
        public string Gender { get; set; } 

        [Required(ErrorMessage = "Date of Birth is required.")]
        [Display(Name = "Date of Birth")]
        [AgeValidation(18, 100)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime DateOfBirth { get; set; } = DateTime.Today;

        [Required(ErrorMessage = "Higher Qualification is required.")]
        [Display(Name = "Higher Qualification")]
        public string HigherQualification { get; set; }

        [StringLength(255)]
        [Display(Name = "Address Line 1")]
        public string AddressLine1 { get; set; }

        [StringLength(255)]
        [Display(Name = "Address Line 2")]
        public string AddressLine2 { get; set; }

        [StringLength(100)]
        public string City { get; set; }

        [StringLength(100)]
        public string State { get; set; }

        [StringLength(20)]
        public string Pincode { get; set; }

        public IFormFile? ProfileImageFile { get; set; }
        
        public string? ProfileImageBase64 { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            // ✔ Condition 1: Required if no existing image
            if (string.IsNullOrEmpty(ProfileImageBase64) && ProfileImageFile == null)
            {
                yield return new ValidationResult(
                    "Profile Image is required",
                    new[] { nameof(ProfileImageFile) });
            }

            // ✔ Condition 2: Validate extension if file uploaded
            if (ProfileImageFile != null)
            {
                var allowedExtensions = new[] { ".jpg", ".jpeg", ".png" };
                var extension = Path.GetExtension(ProfileImageFile.FileName).ToLower();

                if (!allowedExtensions.Contains(extension))
                {
                    yield return new ValidationResult(
                        "Only .jpg, .jpeg, .png files are allowed",
                        new[] { nameof(ProfileImageFile) });
                }

                // ✔ Optional: File size (max 10MB)
                if (ProfileImageFile.Length > 10 * 1024 * 1024)
                {
                    yield return new ValidationResult(
                        "File size must be less than 10MB",
                        new[] { nameof(ProfileImageFile) });
                }
            }
        }
    }
}
