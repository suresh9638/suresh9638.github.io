using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using UserMVC.Helpers;
using UserMVC.Models;
using UserMVC.Services;
using UserMVC.ViewModels;

namespace UserMVC.Controllers
{
    public class UserController : Controller
    {
        private readonly IUserService _userService;

        public UserController(IUserService userService)
        {
            _userService = userService;
        }

        public async Task<IActionResult> Index()
        {
            var users = await _userService.GetAllUsersAsync();
            return View(users);
        }

        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var user = await _userService.GetUserByIdAsync(id.Value);
            if (user == null) return NotFound();

            var viewModel = new UserViewModel
            {
                UserId = user.UserId,
                FirstName = user.FirstName,
                LastName = user.LastName,
                Email = user.Email,
                MobileNumber = user.MobileNumber,
                Designation = user.Designation,
                Gender = user.Gender,
                DateOfBirth = user.DateOfBirth,
                HigherQualification = user.HigherQualification,
                AddressLine1 = user.AddressLine1,
                AddressLine2 = user.AddressLine2,
                City = user.City,
                State = user.State,
                Pincode = user.Pincode,
                ProfileImageBase64 = ImageHelper.ConvertToBase64(user.ProfileImage)
            };

            return View(viewModel);
        }

        public IActionResult Create()
        {
            return View(new UserViewModel());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(UserViewModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var user = new User
                    {
                        FirstName = model.FirstName,
                        LastName = model.LastName,
                        Email = model.Email,
                        MobileNumber = model.MobileNumber,
                        Designation = model.Designation,
                        Gender = model.Gender,
                        DateOfBirth = model.DateOfBirth,
                        HigherQualification = model.HigherQualification,
                        AddressLine1 = model.AddressLine1,
                        AddressLine2 = model.AddressLine2,
                        City = model.City,
                        State = model.State,
                        Pincode = model.Pincode
                    };

                    if (model.ProfileImageFile != null)
                    {
                        user.ProfileImage = await ImageHelper.ConvertToBytesAsync(model.ProfileImageFile);
                    }

                    await _userService.AddUserAsync(user);
                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", ex.Message);
                }
            }
            return View(model);
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var user = await _userService.GetUserByIdAsync(id.Value);
            if (user == null) return NotFound();

            var viewModel = new UserViewModel
            {
                UserId = user.UserId,
                FirstName = user.FirstName,
                LastName = user.LastName,
                Email = user.Email,
                MobileNumber = user.MobileNumber,
                Designation = user.Designation,
                Gender = user.Gender,
                DateOfBirth = user.DateOfBirth,
                HigherQualification = user.HigherQualification,
                AddressLine1 = user.AddressLine1,
                AddressLine2 = user.AddressLine2,
                City = user.City,
                State = user.State,
                Pincode = user.Pincode,
                ProfileImageBase64 = ImageHelper.ConvertToBase64(user.ProfileImage)
            };

            return View(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, UserViewModel model)
        {
            if (id != model.UserId) return NotFound();

            // Ignore image requirement when editing as the user may want to keep the existing image
            ModelState.Remove("ProfileImageFile");

            if (ModelState.IsValid)
            {
                try
                {
                    var existingUser = await _userService.GetUserByIdAsync(id);
                    if (existingUser == null) return NotFound();

                    existingUser.FirstName = model.FirstName;
                    existingUser.LastName = model.LastName;
                    existingUser.Email = model.Email;
                    existingUser.MobileNumber = model.MobileNumber;
                    existingUser.Designation = model.Designation;
                    existingUser.Gender = model.Gender;
                    existingUser.DateOfBirth = model.DateOfBirth;
                    existingUser.HigherQualification = model.HigherQualification;
                    existingUser.AddressLine1 = model.AddressLine1;
                    existingUser.AddressLine2 = model.AddressLine2;
                    existingUser.City = model.City;
                    existingUser.State = model.State;
                    existingUser.Pincode = model.Pincode;

                    if (model.ProfileImageFile != null)
                    {
                        existingUser.ProfileImage = await ImageHelper.ConvertToBytesAsync(model.ProfileImageFile);
                    }

                    await _userService.UpdateUserAsync(existingUser);
                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", ex.Message);
                }
            }

            var userFail = await _userService.GetUserByIdAsync(id);
            if (userFail != null)
            {
                model.ProfileImageBase64 = ImageHelper.ConvertToBase64(userFail.ProfileImage);
            }

            return View(model);
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var user = await _userService.GetUserByIdAsync(id.Value);
            if (user == null) return NotFound();

            var viewModel = new UserViewModel
            {
                UserId = user.UserId,
                FirstName = user.FirstName,
                LastName = user.LastName,
                Email = user.Email,
                ProfileImageBase64 = ImageHelper.ConvertToBase64(user.ProfileImage)
            };

            return View(viewModel);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            await _userService.DeleteUserAsync(id);
            return RedirectToAction(nameof(Index));
        }
    }
}
