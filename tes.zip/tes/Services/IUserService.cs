using System.Collections.Generic;
using System.Threading.Tasks;
using UserMVC.Models;

namespace UserMVC.Services
{
    public interface IUserService
    {
        Task<IEnumerable<User>> GetAllUsersAsync(string? search = null);
        Task<User?> GetUserByIdAsync(int id);
        Task AddUserAsync(User user);
        Task UpdateUserAsync(User user);
        Task DeleteUserAsync(int id);
    }
}
