using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using UserMVC.Models;
using UserMVC.Repository;

namespace UserMVC.Services
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;

        public UserService(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        public async Task<IEnumerable<User>> GetAllUsersAsync(string? search = null)
        {
            return await _userRepository.GetAllAsync(search);
        }

        public async Task<User?> GetUserByIdAsync(int id)
        {
            return await _userRepository.GetByIdAsync(id);
        }

        public async Task AddUserAsync(User user)
        {
            ValidateAge(user.DateOfBirth);
            await _userRepository.AddAsync(user);
        }

        public async Task UpdateUserAsync(User user)
        {
            ValidateAge(user.DateOfBirth);
            await _userRepository.UpdateAsync(user);
        }

        public async Task DeleteUserAsync(int id)
        {
            await _userRepository.DeleteAsync(id);
        }

        private void ValidateAge(DateTime dateOfBirth)
        {
            var age = DateTime.Today.Year - dateOfBirth.Year;
            if (dateOfBirth.Date > DateTime.Today.AddYears(-age)) age--;

            if (age < 18 || age > 100)
            {
                throw new Exception("Age must be between 18 and 100 years.");
            }
        }
    }
}
