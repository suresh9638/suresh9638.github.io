using System.Collections.Generic;
using System.Threading.Tasks;
using UserMVC.Models;

namespace UserMVC.Repository
{
    public interface IUserRepository
    {
        Task<IEnumerable<User>> GetAllAsync(string? search = null);
        Task<User?> GetByIdAsync(int id);
        Task AddAsync(User user);
        Task UpdateAsync(User user);
        Task DeleteAsync(int id);
    }
}
